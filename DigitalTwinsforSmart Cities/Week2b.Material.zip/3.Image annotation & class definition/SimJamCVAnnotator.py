import customtkinter as ctk
from tkinter import filedialog, messagebox, Canvas
import cv2
import os
import sys
import subprocess
from PIL import Image, ImageTk
import numpy as np
import threading

# Set appearance mode and color theme
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

class YOLOAnnotator:
    def __init__(self, root):
        self.root = root
        self.root.title("SimJam ComputerVision - YOLO Annotator")
        self.root.geometry("1400x900")
        
        # Variables
        self.image_path = None
        self.output_dir = None
        self.original_img = None
        self.display_img = None
        self.rectangles = []
        self.drawing = False
        self.ix, self.iy = -1, -1
        self.current_class_id = 3
        self.scale_factor = 1.0
        
        # Class names mapping
        self.class_names = {
            0: "pedestrian",
            1: "people",
            2: "bicycle",
            3: "car",
            4: "van",
            5: "truck",
            6: "tricycle",
            7: "awning-tricycle",
            8: "bus",
            9: "motor"
        }
        
        self.setup_ui()
        
    def setup_ui(self):
        # Main container
        main_container = ctk.CTkFrame(self.root, fg_color="transparent")
        main_container.pack(fill="both", expand=True)
        
        # Header Frame with Logo and About/Dependencies buttons
        self.create_header(main_container)
        
        # Control Panel Frame
        self.create_control_panel(main_container)
        
        # Canvas Frame for image display
        self.create_canvas_frame(main_container)
        
    def create_header(self, parent):
        """Create header with logo and buttons"""
        header_frame = ctk.CTkFrame(parent, height=60, corner_radius=0)
        header_frame.pack(fill="x", padx=0, pady=(0, 10))
        header_frame.pack_propagate(False)
        
        # Left side: Logo and Title
        left_frame = ctk.CTkFrame(header_frame, fg_color="transparent")
        left_frame.pack(side="left", padx=15, pady=10)
        
        # Try to load logo
        logo_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "RoadwayVR.jpg")
        if os.path.exists(logo_path):
            try:
                logo_image = Image.open(logo_path)
                logo_image = logo_image.resize((40, 40), Image.Resampling.LANCZOS)
                self.logo_photo = ctk.CTkImage(light_image=logo_image, dark_image=logo_image, size=(40, 40))
                logo_label = ctk.CTkLabel(left_frame, image=self.logo_photo, text="")
                logo_label.pack(side="left", padx=(0, 12))
            except Exception as e:
                print(f"Could not load logo: {e}")
        
        # Title
        title_label = ctk.CTkLabel(left_frame, text="SimJam ComputerVision - YOLO Annotator",
                                   font=ctk.CTkFont(size=18, weight="bold"))
        title_label.pack(side="left")
        
        # Right side: About and Dependencies buttons
        right_frame = ctk.CTkFrame(header_frame, fg_color="transparent")
        right_frame.pack(side="right", padx=15, pady=10)
        
        about_btn = ctk.CTkButton(right_frame, text="ℹ About", command=self.show_about,
                                 width=100, height=32)
        about_btn.pack(side="left", padx=(0, 10))
        
        dependencies_btn = ctk.CTkButton(right_frame, text="🔧 Dependencies",
                                        command=self.show_dependencies, width=140, height=32)
        dependencies_btn.pack(side="left")
        
    def create_control_panel(self, parent):
        """Create control panel with all buttons"""
        control_frame = ctk.CTkFrame(parent, height=80, corner_radius=0)
        control_frame.pack(fill="x", padx=0, pady=(0, 10))
        control_frame.pack_propagate(False)
        
        # Container for buttons (centered)
        button_container = ctk.CTkFrame(control_frame, fg_color="transparent")
        button_container.pack(expand=True)
        
        # Load Image Button
        self.btn_load = ctk.CTkButton(button_container, text="📁  Load Image",
                                      command=self.load_image, width=140, height=40)
        self.btn_load.pack(side="left", padx=8)
        
        # Set Output Directory Button
        self.btn_output = ctk.CTkButton(button_container, text="📂  Set Output",
                                       command=self.set_output_directory, width=140, height=40,
                                       fg_color="#9333EA", hover_color="#7C3AED")
        self.btn_output.pack(side="left", padx=8)
        
        # Separator
        sep1 = ctk.CTkFrame(button_container, width=2, height=40, fg_color="gray30")
        sep1.pack(side="left", padx=15)
        
        # Class Selection
        class_frame = ctk.CTkFrame(button_container, fg_color="transparent")
        class_frame.pack(side="left", padx=8)
        
        ctk.CTkLabel(class_frame, text="Class:", font=ctk.CTkFont(size=12, weight="bold")).pack(side="left", padx=(0, 8))
        
        self.class_var = ctk.StringVar(value="3 - car")
        class_dropdown = ctk.CTkComboBox(class_frame, variable=self.class_var,
                                        values=[f"{k} - {v}" for k, v in self.class_names.items()],
                                        state="readonly", width=180, height=40,
                                        command=self.on_class_change)
        class_dropdown.pack(side="left")
        
        # Separator
        sep2 = ctk.CTkFrame(button_container, width=2, height=40, fg_color="gray30")
        sep2.pack(side="left", padx=15)
        
        # Undo Button
        self.btn_undo = ctk.CTkButton(button_container, text="↶  Undo",
                                     command=self.undo_last, width=120, height=40,
                                     fg_color="#F97316", hover_color="#EA580C")
        self.btn_undo.pack(side="left", padx=8)
        
        # Clear All Button
        self.btn_clear = ctk.CTkButton(button_container, text="🗑️  Clear",
                                      command=self.clear_all, width=120, height=40,
                                      fg_color="#EF4444", hover_color="#DC2626")
        self.btn_clear.pack(side="left", padx=8)
        
        # Save Button
        self.btn_save = ctk.CTkButton(button_container, text="💾  Save Labels",
                                     command=self.save_labels, width=140, height=40,
                                     fg_color="#10B981", hover_color="#059669")
        self.btn_save.pack(side="left", padx=8)
        
        # Box Count Label
        self.count_label = ctk.CTkLabel(button_container, text="0",
                                       font=ctk.CTkFont(size=18, weight="bold"),
                                       fg_color="#10B981", corner_radius=8,
                                       width=60, height=40)
        self.count_label.pack(side="left", padx=20)
        
    def create_canvas_frame(self, parent):
        """Create canvas for image display"""
        canvas_frame = ctk.CTkFrame(parent, corner_radius=0)
        canvas_frame.pack(fill="both", expand=True, padx=10, pady=(0, 10))
        
        # Use tkinter Canvas (not CTkCanvas) for image display and mouse events
        self.canvas = Canvas(canvas_frame, bg="#1a1a1a", highlightthickness=0)
        self.canvas.pack(fill="both", expand=True, padx=5, pady=5)
        
        # Bind mouse events
        self.canvas.bind("<ButtonPress-1>", self.on_mouse_down)
        self.canvas.bind("<B1-Motion>", self.on_mouse_move)
        self.canvas.bind("<ButtonRelease-1>", self.on_mouse_up)
        
    def on_class_change(self, choice):
        """Handle class selection change"""
        self.current_class_id = int(choice.split(" - ")[0])
        
    def load_image(self):
        """Load an image file"""
        file_path = filedialog.askopenfilename(
            title="Select Image",
            filetypes=[("Image files", "*.jpg *.jpeg *.png *.bmp"), ("All files", "*.*")]
        )
        
        if file_path:
            self.image_path = file_path
            self.original_img = cv2.imread(file_path)
            
            if self.original_img is None:
                messagebox.showerror("Error", "Failed to load image!")
                return
            
            # Clear previous annotations
            self.rectangles = []
            self.update_count()
            
            # Calculate scale to fit canvas
            canvas_width = self.canvas.winfo_width()
            canvas_height = self.canvas.winfo_height()
            
            if canvas_width > 1 and canvas_height > 1:
                img_height, img_width = self.original_img.shape[:2]
                scale_w = canvas_width / img_width
                scale_h = canvas_height / img_height
                self.scale_factor = min(scale_w, scale_h, 1.0) * 0.95
            else:
                self.scale_factor = 0.8
            
            self.display_image()
            
    def set_output_directory(self):
        """Set output directory for labels"""
        directory = filedialog.askdirectory(title="Select Output Directory")
        if directory:
            self.output_dir = directory
            messagebox.showinfo("Success", f"Output directory set to:\n{directory}")
            
    def display_image(self):
        """Display image on canvas"""
        if self.original_img is None:
            return
        
        img_copy = self.original_img.copy()
        
        # Draw all rectangles
        for rect in self.rectangles:
            xmin, ymin, xmax, ymax, class_id = rect
            color = self.get_class_color(class_id)
            cv2.rectangle(img_copy, (xmin, ymin), (xmax, ymax), color, 2)
            
            # Draw label
            label = f"{class_id}: {self.class_names[class_id]}"
            (text_width, text_height), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)
            cv2.rectangle(img_copy, (xmin, ymin - text_height - 8),
                         (xmin + text_width + 8, ymin), color, -1)
            cv2.putText(img_copy, label, (xmin + 4, ymin - 4),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        
        # Convert and resize
        img_rgb = cv2.cvtColor(img_copy, cv2.COLOR_BGR2RGB)
        pil_img = Image.fromarray(img_rgb)
        
        new_width = int(img_copy.shape[1] * self.scale_factor)
        new_height = int(img_copy.shape[0] * self.scale_factor)
        pil_img = pil_img.resize((new_width, new_height), Image.Resampling.LANCZOS)
        
        self.display_img = ImageTk.PhotoImage(pil_img)
        self.canvas.delete("all")
        self.canvas.create_image(0, 0, anchor="nw", image=self.display_img)
        
    def get_class_color(self, class_id):
        """Get color for each class"""
        colors = [
            (255, 0, 0), (0, 255, 0), (0, 0, 255), (255, 255, 0),
            (255, 0, 255), (0, 255, 255), (128, 0, 128), (255, 165, 0),
            (0, 128, 128), (128, 128, 0)
        ]
        return colors[class_id % len(colors)]
        
    def on_mouse_down(self, event):
        """Handle mouse button press"""
        if self.original_img is None:
            return
        
        self.drawing = True
        self.ix = int(event.x / self.scale_factor)
        self.iy = int(event.y / self.scale_factor)
        
    def on_mouse_move(self, event):
        """Handle mouse movement while drawing"""
        if not self.drawing or self.original_img is None:
            return
        
        x = int(event.x / self.scale_factor)
        y = int(event.y / self.scale_factor)
        
        # Constrain to image bounds
        h, w = self.original_img.shape[:2]
        x = max(0, min(x, w))
        y = max(0, min(y, h))
        
        # Draw preview
        img_copy = self.original_img.copy()
        
        # Draw existing rectangles
        for rect in self.rectangles:
            xmin, ymin, xmax, ymax, class_id = rect
            color = self.get_class_color(class_id)
            cv2.rectangle(img_copy, (xmin, ymin), (xmax, ymax), color, 2)
            
            label = f"{class_id}: {self.class_names[class_id]}"
            (text_width, text_height), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)
            cv2.rectangle(img_copy, (xmin, ymin - text_height - 8),
                         (xmin + text_width + 8, ymin), color, -1)
            cv2.putText(img_copy, label, (xmin + 4, ymin - 4),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        
        # Draw current rectangle
        color = self.get_class_color(self.current_class_id)
        cv2.rectangle(img_copy, (self.ix, self.iy), (x, y), color, 3)
        
        # Update display
        img_rgb = cv2.cvtColor(img_copy, cv2.COLOR_BGR2RGB)
        pil_img = Image.fromarray(img_rgb)
        
        new_width = int(img_copy.shape[1] * self.scale_factor)
        new_height = int(img_copy.shape[0] * self.scale_factor)
        pil_img = pil_img.resize((new_width, new_height), Image.Resampling.LANCZOS)
        
        self.display_img = ImageTk.PhotoImage(pil_img)
        self.canvas.delete("all")
        self.canvas.create_image(0, 0, anchor="nw", image=self.display_img)
        
    def on_mouse_up(self, event):
        """Handle mouse button release"""
        if not self.drawing or self.original_img is None:
            return
        
        self.drawing = False
        
        x = int(event.x / self.scale_factor)
        y = int(event.y / self.scale_factor)
        
        # Constrain to image bounds
        h, w = self.original_img.shape[:2]
        x = max(0, min(x, w))
        y = max(0, min(y, h))
        
        # Create rectangle
        xmin = min(self.ix, x)
        ymin = min(self.iy, y)
        xmax = max(self.ix, x)
        ymax = max(self.iy, y)
        
        # Only add if rectangle has size
        if xmax - xmin > 5 and ymax - ymin > 5:
            self.rectangles.append([xmin, ymin, xmax, ymax, self.current_class_id])
            self.update_count()
        
        self.display_image()
        
    def undo_last(self):
        """Remove last annotation"""
        if self.rectangles:
            self.rectangles.pop()
            self.update_count()
            self.display_image()
            
    def clear_all(self):
        """Clear all annotations"""
        if self.rectangles:
            if messagebox.askyesno("Confirm", "Clear all annotations?"):
                self.rectangles = []
                self.update_count()
                self.display_image()
                
    def update_count(self):
        """Update box count display"""
        self.count_label.configure(text=str(len(self.rectangles)))
        
    def save_labels(self):
        """Save annotations in YOLO format"""
        if self.original_img is None:
            messagebox.showwarning("Warning", "No image loaded!")
            return
        
        if not self.rectangles:
            messagebox.showwarning("Warning", "No annotations to save!")
            return
        
        if not self.output_dir:
            messagebox.showwarning("Warning", "Please set output directory first!")
            return
        
        # Get image dimensions
        h, w = self.original_img.shape[:2]
        
        # Get base filename
        base = os.path.splitext(os.path.basename(self.image_path))[0]
        
        # Write YOLO format labels
        label_path = os.path.join(self.output_dir, f"{base}.txt")
        
        with open(label_path, 'w') as f:
            for rect in self.rectangles:
                xmin, ymin, xmax, ymax, class_id = rect
                
                # Convert to YOLO format (normalized)
                x_center = ((xmin + xmax) / 2) / w
                y_center = ((ymin + ymax) / 2) / h
                bw = (xmax - xmin) / w
                bh = (ymax - ymin) / h
                f.write(f"{class_id} {x_center:.6f} {y_center:.6f} {bw:.6f} {bh:.6f}\n")
        
        messagebox.showinfo("Success", f"Saved {len(self.rectangles)} annotations!\n\n{base}.txt")
        
    def show_about(self):
        """Show About dialog"""
        about_window = ctk.CTkToplevel(self.root)
        about_window.title("About")
        about_window.geometry("350x220")
        about_window.resizable(False, False)
        about_window.transient(self.root)
        about_window.grab_set()
        
        # Content frame
        content_frame = ctk.CTkFrame(about_window, fg_color="transparent")
        content_frame.pack(fill="both", expand=True, padx=25, pady=20)
        
        # Title
        ctk.CTkLabel(content_frame, text="About",
                    font=ctk.CTkFont(size=18, weight="bold")).pack(pady=(0, 12))
        
        # Developed by
        ctk.CTkLabel(content_frame, text="Developed by RoadwayVR",
                    font=ctk.CTkFont(size=13, weight="bold"),
                    text_color="lightblue").pack(pady=(0, 10))
        
        # Application
        ctk.CTkLabel(content_frame, text="Application:",
                    font=ctk.CTkFont(size=10), text_color="gray60").pack(pady=(0, 2))
        ctk.CTkLabel(content_frame, text="SimJamCV Annotator",
                    font=ctk.CTkFont(size=12, weight="bold")).pack(pady=(0, 8))
        
        # Version
        ctk.CTkLabel(content_frame, text="Version: 1.0",
                    font=ctk.CTkFont(size=11)).pack(pady=(0, 8))
        
        # Description
        ctk.CTkLabel(content_frame, text="YOLO format annotation tool\nfor object detection datasets",
                    font=ctk.CTkFont(size=10), text_color="gray60",
                    justify="center").pack(pady=(0, 12))
        
        # Close button
        ctk.CTkButton(content_frame, text="Close", command=about_window.destroy,
                     width=100, height=28).pack()
        
    def show_dependencies(self):
        """Show Dependencies dialog"""
        dep_window = ctk.CTkToplevel(self.root)
        dep_window.title("Dependency Manager")
        dep_window.geometry("700x500")
        dep_window.resizable(False, False)
        dep_window.transient(self.root)
        dep_window.grab_set()
        
        # Main frame
        main_frame = ctk.CTkFrame(dep_window)
        main_frame.pack(fill="both", expand=True, padx=20, pady=20)
        
        # Header
        header_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
        header_frame.pack(fill="x", pady=(0, 15))
        
        ctk.CTkLabel(header_frame, text="📦 Package Dependencies",
                    font=ctk.CTkFont(size=18, weight="bold")).pack(side="left")
        ctk.CTkLabel(header_frame, text="Check and install required Python packages",
                    text_color="gray60").pack(side="left", padx=(15, 0))
        
        # Console
        console_frame = ctk.CTkFrame(main_frame)
        console_frame.pack(fill="both", expand=True, pady=(0, 15))
        
        console = ctk.CTkTextbox(console_frame, font=ctk.CTkFont(family="Courier", size=11),
                                wrap="word")
        console.pack(fill="both", expand=True, padx=10, pady=10)
        
        def log_message(message):
            console.configure(state="normal")
            console.insert("end", message + "\n")
            console.see("end")
            console.configure(state="disabled")
            dep_window.update()
        
        # Buttons
        button_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
        button_frame.pack(fill="x")
        
        check_btn = ctk.CTkButton(button_frame, text="🔍 Check Status", width=150)
        check_btn.pack(side="left", padx=(0, 10))
        
        install_btn = ctk.CTkButton(button_frame, text="⬇ Install Missing", width=150,
                                   fg_color="green", hover_color="darkgreen")
        install_btn.pack(side="left", padx=(0, 10))
        
        close_btn = ctk.CTkButton(button_frame, text="Close", width=100,
                                 command=dep_window.destroy)
        close_btn.pack(side="right")
        
        # Required packages
        REQUIRED_PACKAGES = {
            'customtkinter': 'customtkinter>=5.2.0',
            'cv2': 'opencv-python>=4.8.0',
            'PIL': 'pillow>=10.0.0',
            'numpy': 'numpy>=1.24.0',
        }
        
        def check_dependencies():
            console.configure(state="normal")
            console.delete("1.0", "end")
            console.configure(state="disabled")
            
            log_message("Checking dependencies...\n")
            log_message("DEPENDENCY STATUS")
            log_message("=" * 50 + "\n")
            
            installed = []
            missing = []
            
            for import_name, pip_name in REQUIRED_PACKAGES.items():
                try:
                    __import__(import_name)
                    installed.append(pip_name.split('>=')[0])
                    log_message(f"✓ {pip_name.split('>=')[0]}")
                except ImportError:
                    missing.append(pip_name)
            
            if missing:
                log_message("\n✗ MISSING:")
                for pkg in missing:
                    log_message(f"  • {pkg}")
                log_message(f"\n⚠ Need to install {len(missing)} package(s)")
                install_btn.configure(state="normal")
            else:
                log_message("\n🎉 All dependencies are installed!")
                install_btn.configure(state="disabled")
            
            return installed, missing
        
        def install_missing():
            def install_worker():
                install_btn.configure(state="disabled")
                check_btn.configure(state="disabled")
                
                log_message("\n" + "=" * 50)
                log_message("INSTALLING MISSING PACKAGES")
                log_message("=" * 50 + "\n")
                
                _, missing = check_dependencies_silent()
                
                if not missing:
                    log_message("All packages already installed!")
                    check_btn.configure(state="normal")
                    return
                
                total = len(missing)
                for i, package in enumerate(missing, 1):
                    log_message(f"Installing {i}/{total}: {package}...")
                    
                    try:
                        result = subprocess.run(
                            [sys.executable, "-m", "pip", "install", package],
                            capture_output=True,
                            text=True,
                            timeout=300
                        )
                        
                        if result.returncode == 0:
                            log_message(f"  ✓ {package} installed successfully")
                        else:
                            log_message(f"  ✗ Failed to install {package}")
                    except Exception as e:
                        log_message(f"  ✗ Error: {str(e)}")
                
                log_message("\n" + "=" * 50)
                log_message("Verifying installation...")
                check_dependencies()
                
                check_btn.configure(state="normal")
                install_btn.configure(state="normal")
            
            threading.Thread(target=install_worker, daemon=True).start()
        
        def check_dependencies_silent():
            installed = []
            missing = []
            
            for import_name, pip_name in REQUIRED_PACKAGES.items():
                try:
                    __import__(import_name)
                    installed.append(pip_name.split('>=')[0])
                except ImportError:
                    missing.append(pip_name)
            
            return installed, missing
        
        check_btn.configure(command=check_dependencies)
        install_btn.configure(command=install_missing)
        
        # Initial check
        check_dependencies()

if __name__ == "__main__":
    root = ctk.CTk()
    app = YOLOAnnotator(root)
    root.mainloop()